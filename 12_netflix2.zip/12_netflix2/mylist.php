<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>IMDFlix</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  
  <div id="netflix">
  <?php include_once("nav.inc.php"); ?>
 
  <h2>My List</h2>

  <div class="collection myList">
    <a href="#" class="collection__item" style="background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSaoJ20qUVNCzeZnQ7Aq2aBiBdpcJQMG4_u2JhNXpvL4mLXwO2H)"></a>
    
    <a href="#" class="collection__item" style="background-image: url(http://www.sickchirpse.com/wp-content/uploads/2017/10/Black-Mirror.jpg)"></a>
  
    <a href="#" class="collection__item" style="background-image: url(https://www.comicbookmovie.com/images/articles/banners/154707.jpg)"></a>

    <a href="#" class="collection__item" style="background-image: url(https://static1.squarespace.com/static/556b9dd0e4b0518b1fa424e9/t/569441c0d8af10cf1a8d4fc3/1452556766943/MaM+Poster-album.jpg?format=300w)"></a>


  </div>
  
</div>

</body>
</html>