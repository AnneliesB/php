<?php

	$collection = [	
		[
			"title"		=>	"Blade Runner 2046",
			"poster" 	=>	"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSaoJ20qUVNCzeZnQ7Aq2aBiBdpcJQMG4_u2JhNXpvL4mLXwO2H"
		],
		[
			"title"		=>	"Black Mirror",
			"poster" 	=>	"http://www.sickchirpse.com/wp-content/uploads/2017/10/Black-Mirror.jpg"
		],
		[
			"title"		=>	"Stranger Things",
			"poster" 	=>	"https://images-na.ssl-images-amazon.com/images/I/91PolkTUn9L._SY679_.jpg"
		],
		[
			"title"		=>	"Making a Murderer",
			"poster" 	=>	"https://static1.squarespace.com/static/556b9dd0e4b0518b1fa424e9/t/569441c0d8af10cf1a8d4fc3/1452556766943/MaM+Poster-album.jpg?format=300w"
		],
		[
			"title"		=>	"Fargo",
			"poster" 	=>	"https://mnprairieroots.files.wordpress.com/2012/06/fargo.jpg"
		],
		[
			"title"		=>	"Chef's Table",
			"poster" 	=>	"http://www.indiewire.com/wp-content/uploads/2016/08/chefs_table_frane_us.jpg"
		],
		[
			"title"		=>	"Abstract",
			"poster" 	=>	"https://images-na.ssl-images-amazon.com/images/M/MV5BMTUyMDU4NzE0Nl5BMl5BanBnXkFtZTgwMzg0MDQyMTI@._V1_UY1200_CR90,0,630,1200_AL_.jpg"
		],
		[
			"title"		=>	"Fauda",
			"poster" 	=>	"https://cdn-static.sidereel.com/tv_shows/60482/giant_2x/MV5BMTk2OTAyOTYtZDFkYi00ZjBjLTgyZTMtODJjYzk1NjBhM2NmXkEyXkFqcGdeQXVyMjMyMzI4MzY_._V1_.jpg"
		],

	];

?>