<nav class="navbar">
    <a href="index.php" class="logo">IMDflix</a>
    <a href="index.php">Home</a>
    <a href="mylist.php">My List</a>
    
    <form action="" method="post">
      <input type="text">
    </form>
    
    <a href="logout.php" class="navbar__logout">Hi Joris, logout?</a>
</nav>